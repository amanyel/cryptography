
package cryptography;
/**
 *
 * @author Amany
 */

public class DESAlgo
{

public static void main(String args[]) {
DES des = new DES();
}
}
